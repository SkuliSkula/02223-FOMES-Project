# 02223-FOMES-Project
A project for the course 02223 Fundamentals of Modern Embedded Systems at DTU. Energy independent households utilizing PV panels: Energyharvesting &amp; off-the-grid households in critical time periods
