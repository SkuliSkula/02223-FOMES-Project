package energy.simulation;
import GenCol.entity;

public class signal extends entity {
	public String name;

}
