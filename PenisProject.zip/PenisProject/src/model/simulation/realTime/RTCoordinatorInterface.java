/* 
 * Author     : ACIMS(Arizona Centre for Integrative Modeling & Simulation)
 *  Version    : DEVSJAVA 2.7 
 *  Date       : 08-15-02 
 */ 


package model.simulation.realTime;


import java.util.*;

import GenCol.*;


import model.simulation.*;



public interface RTCoordinatorInterface extends
 CoordinatorInterface,Runnable{
}