/*     
 *    
 *  Author     : ACIMS(Arizona Centre for Integrative Modeling & Simulation)
 *  Version    : DEVSJAVA 2.7 
 *  Date       : 08-15-02 
 */
package util;

public class HtmlUtil
{
    static public String tooltipHeader =
        "<html><body style=\"font-size:12pt; font-family:'sans-serif'\">";
    static public String yellowTooltipHeader =
        "<html><body bgcolor=#FFFFCC style=\"font-size:12pt; font-family:'sans-serif'\">";
}